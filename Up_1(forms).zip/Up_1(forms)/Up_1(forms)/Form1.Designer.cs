﻿namespace Up_1_forms_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtProductName = new TextBox();
            txtProductPrice = new TextBox();
            txtProductCount = new TextBox();
            btnAddProduct = new Button();
            btnSellProduct = new Button();
            txtSellProductName = new TextBox();
            txtSellProductCount = new TextBox();
            lblProfit = new Label();
            listBoxProducts = new ListBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tabPage2 = new TabPage();
            listBoxSongs = new ListBox();
            lblCurrentSong = new Label();
            btnClear = new Button();
            btnPrevious = new Button();
            btnNext = new Button();
            btnAddSong = new Button();
            txtFilename = new TextBox();
            txtTitle = new TextBox();
            txtAuthor = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // txtProductName
            // 
            txtProductName.Location = new Point(93, 10);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(125, 27);
            txtProductName.TabIndex = 0;
            // 
            // txtProductPrice
            // 
            txtProductPrice.Location = new Point(93, 43);
            txtProductPrice.Name = "txtProductPrice";
            txtProductPrice.Size = new Size(125, 27);
            txtProductPrice.TabIndex = 1;
            // 
            // txtProductCount
            // 
            txtProductCount.Location = new Point(93, 82);
            txtProductCount.Name = "txtProductCount";
            txtProductCount.Size = new Size(125, 27);
            txtProductCount.TabIndex = 2;
            // 
            // btnAddProduct
            // 
            btnAddProduct.Location = new Point(93, 115);
            btnAddProduct.Name = "btnAddProduct";
            btnAddProduct.Size = new Size(125, 29);
            btnAddProduct.TabIndex = 3;
            btnAddProduct.Text = "Добавить";
            btnAddProduct.UseVisualStyleBackColor = true;
            btnAddProduct.Click += btnAddProduct_Click;
            // 
            // btnSellProduct
            // 
            btnSellProduct.Location = new Point(466, 96);
            btnSellProduct.Name = "btnSellProduct";
            btnSellProduct.Size = new Size(94, 29);
            btnSellProduct.TabIndex = 4;
            btnSellProduct.Text = "Купить";
            btnSellProduct.UseVisualStyleBackColor = true;
            btnSellProduct.Click += btnSellProduct_Click;
            // 
            // txtSellProductName
            // 
            txtSellProductName.Location = new Point(466, 6);
            txtSellProductName.Name = "txtSellProductName";
            txtSellProductName.Size = new Size(125, 27);
            txtSellProductName.TabIndex = 5;
            // 
            // txtSellProductCount
            // 
            txtSellProductCount.Location = new Point(466, 49);
            txtSellProductCount.Name = "txtSellProductCount";
            txtSellProductCount.Size = new Size(125, 27);
            txtSellProductCount.TabIndex = 6;
            // 
            // lblProfit
            // 
            lblProfit.AutoSize = true;
            lblProfit.Location = new Point(6, 353);
            lblProfit.Name = "lblProfit";
            lblProfit.Size = new Size(74, 20);
            lblProfit.TabIndex = 7;
            lblProfit.Text = "Прибыль";
            // 
            // listBoxProducts
            // 
            listBoxProducts.FormattingEnabled = true;
            listBoxProducts.ItemHeight = 20;
            listBoxProducts.Location = new Point(7, 197);
            listBoxProducts.Name = "listBoxProducts";
            listBoxProducts.Size = new Size(434, 124);
            listBoxProducts.TabIndex = 8;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(2, 2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(800, 448);
            tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(txtProductName);
            tabPage1.Controls.Add(listBoxProducts);
            tabPage1.Controls.Add(txtProductPrice);
            tabPage1.Controls.Add(lblProfit);
            tabPage1.Controls.Add(txtProductCount);
            tabPage1.Controls.Add(btnSellProduct);
            tabPage1.Controls.Add(txtSellProductCount);
            tabPage1.Controls.Add(btnAddProduct);
            tabPage1.Controls.Add(txtSellProductName);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(792, 415);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Магазин";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(7, 174);
            label6.Name = "label6";
            label6.Size = new Size(165, 20);
            label6.TabIndex = 14;
            label6.Text = "Продукты в наличии:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(383, 50);
            label5.Name = "label5";
            label5.Size = new Size(58, 20);
            label5.TabIndex = 13;
            label5.Text = "Кол-во";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(383, 10);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 12;
            label4.Text = "Название";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 82);
            label3.Name = "label3";
            label3.Size = new Size(58, 20);
            label3.TabIndex = 11;
            label3.Text = "Кол-во";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 45);
            label2.Name = "label2";
            label2.Size = new Size(45, 20);
            label2.TabIndex = 10;
            label2.Text = "Цена";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 13);
            label1.Name = "label1";
            label1.Size = new Size(81, 20);
            label1.TabIndex = 9;
            label1.Text = "Название ";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(listBoxSongs);
            tabPage2.Controls.Add(lblCurrentSong);
            tabPage2.Controls.Add(btnClear);
            tabPage2.Controls.Add(btnPrevious);
            tabPage2.Controls.Add(btnNext);
            tabPage2.Controls.Add(btnAddSong);
            tabPage2.Controls.Add(txtFilename);
            tabPage2.Controls.Add(txtTitle);
            tabPage2.Controls.Add(txtAuthor);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(792, 415);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Плейлист";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // listBoxSongs
            // 
            listBoxSongs.FormattingEnabled = true;
            listBoxSongs.ItemHeight = 20;
            listBoxSongs.Location = new Point(185, 6);
            listBoxSongs.Name = "listBoxSongs";
            listBoxSongs.Size = new Size(264, 144);
            listBoxSongs.TabIndex = 8;
            // 
            // lblCurrentSong
            // 
            lblCurrentSong.AutoSize = true;
            lblCurrentSong.Location = new Point(465, 6);
            lblCurrentSong.Name = "lblCurrentSong";
            lblCurrentSong.Size = new Size(50, 20);
            lblCurrentSong.TabIndex = 7;
            lblCurrentSong.Text = "label7";
            // 
            // btnClear
            // 
            btnClear.Location = new Point(376, 199);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 29);
            btnClear.TabIndex = 6;
            btnClear.Text = "очистить";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click_1;
            // 
            // btnPrevious
            // 
            btnPrevious.Location = new Point(258, 199);
            btnPrevious.Name = "btnPrevious";
            btnPrevious.Size = new Size(94, 29);
            btnPrevious.TabIndex = 5;
            btnPrevious.Text = "назад";
            btnPrevious.UseVisualStyleBackColor = true;
            btnPrevious.Click += btnPrevious_Click_1;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(137, 199);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(94, 29);
            btnNext.TabIndex = 4;
            btnNext.Text = "дальше";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click_1;
            // 
            // btnAddSong
            // 
            btnAddSong.Location = new Point(15, 199);
            btnAddSong.Name = "btnAddSong";
            btnAddSong.Size = new Size(94, 29);
            btnAddSong.TabIndex = 3;
            btnAddSong.Text = "добавить";
            btnAddSong.UseVisualStyleBackColor = true;
            btnAddSong.Click += btnAddSong_Click_1;
            // 
            // txtFilename
            // 
            txtFilename.Location = new Point(15, 135);
            txtFilename.Name = "txtFilename";
            txtFilename.Size = new Size(125, 27);
            txtFilename.TabIndex = 2;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(15, 79);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(125, 27);
            txtTitle.TabIndex = 1;
            // 
            // txtAuthor
            // 
            txtAuthor.Location = new Point(15, 26);
            txtAuthor.Name = "txtAuthor";
            txtAuthor.Size = new Size(125, 27);
            txtAuthor.TabIndex = 0;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(15, 3);
            label7.Name = "label7";
            label7.Size = new Size(54, 20);
            label7.TabIndex = 9;
            label7.Text = "Автор:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(15, 56);
            label8.Name = "label8";
            label8.Size = new Size(80, 20);
            label8.TabIndex = 10;
            label8.Text = "Название:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(15, 112);
            label9.Name = "label9";
            label9.Size = new Size(164, 20);
            label9.TabIndex = 11;
            label9.Text = "Путь к файлу(song.txt) ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox txtProductName;
        private TextBox txtProductPrice;
        private TextBox txtProductCount;
        private Button btnAddProduct;
        private Button btnSellProduct;
        private TextBox txtSellProductName;
        private TextBox txtSellProductCount;
        private Label lblProfit;
        private ListBox listBoxProducts;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TabPage tabPage2;
        private Label lblCurrentSong;
        private Button btnClear;
        private Button btnPrevious;
        private Button btnNext;
        private Button btnAddSong;
        private TextBox txtFilename;
        private TextBox txtTitle;
        private TextBox txtAuthor;
        private ListBox listBoxSongs;
        private Label label9;
        private Label label8;
        private Label label7;
    }
}
