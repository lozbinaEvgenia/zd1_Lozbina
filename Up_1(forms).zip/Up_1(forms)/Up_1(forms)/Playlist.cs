﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Up_1_forms_
{
    public struct Song
    {
        public string Author;
        public string Title;
        public string Filename;

        public Song(string author, string title, string filename)
        {
            Author = author;
            Title = title;
            Filename = filename;
        }
    }
    public class Playlist
    {
        private List<Song> list;
        private int currentIndex;

        public Playlist()
        {
            list = new List<Song>();
            currentIndex = 0;
        }

        // Получить текущую песню
        public Song CurrentSong()
        {
            if (list.Count > 0)
                return list[currentIndex];
            else
                throw new IndexOutOfRangeException("Невозможно получить текущую аудиозапись для пустого плейлиста!");
        }

        // Добавить песню
        public void AddSong(Song song)
        {
            list.Add(song);
        }

        // Перегрузка для добавления песни с параметрами
        public void AddSong(string author, string title, string filename)
        {
            Song song = new Song(author, title, filename);
            AddSong(song);
        }

        // Перейти к следующей песне
        public void Next()
        {
            if (list.Count > 0)
            {
                currentIndex = (currentIndex + 1) % list.Count; // Циклический переход
            }
        }

        // Перейти к предыдущей песне
        public void Previous()
        {
            if (list.Count > 0)
            {
                currentIndex = (currentIndex - 1 + list.Count) % list.Count; // Циклический переход
            }
        }

        // Перейти по индексу
        public void GoTo(int index)
        {
            if (index >= 0 && index < list.Count)
                currentIndex = index;
            else
                throw new IndexOutOfRangeException("Индекс находится вне диапазона!");
        }

        // Перейти к началу списка
        public void GoToStart()
        {
            currentIndex = 0;
        }

        // Удалить композицию по индексу
        public void RemoveAt(int index)
        {
            if (index >= 0 && index < list.Count)
            {
                list.RemoveAt(index);
                if (currentIndex >= list.Count) // Если текущий индекс выходит за пределы
                    currentIndex = list.Count - 1;
            }
            else
            {
                throw new IndexOutOfRangeException("Индекс находится вне диапазона!");
            }
        }

        // Удалить композицию по значению
        public void Remove(Song song)
        {
            list.Remove(song);
            if (currentIndex >= list.Count) // Если текущий индекс выходит за пределы
                currentIndex = list.Count - 1;
        }

        // Очистить плейлист
        public void Clear()
        {
            list.Clear();
            currentIndex = 0; // Сброс индекса
        }

        // Получить все песни
        public List<Song> GetSongs()
        {
            return new List<Song>(list);
        }
        public int CurrentIndex
        {
            get { return currentIndex; }
        }
    }
}
