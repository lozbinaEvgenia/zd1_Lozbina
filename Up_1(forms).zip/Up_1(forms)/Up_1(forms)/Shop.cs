﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Up_1_forms_
{
    public class Shop
    {
        private Dictionary<Product, int> products;
        private decimal profit;

        public Shop()
        {
            products = new Dictionary<Product, int>();
            profit = 0;
        }

        public void AddProduct(Product product, int count)
        {
            if (products.ContainsKey(product))
            {
                products[product] += count; // Увеличиваем количество, если продукт уже существует
            }
            else
            {
                products.Add(product, count);
            }
        }

        public void CreateProduct(string name, decimal price, int count)
        {
            // Проверяем, существует ли продукт с таким именем
            if (FindByName(name) != null)
            {
                MessageBox.Show("Продукт с таким именем уже существует.");
                return;
            }

            AddProduct(new Product(name, price), count);
        }

        public void WriteAllProducts()
        {
            foreach (var product in products)
            {
                Console.WriteLine(product.Key.GetInfo() + $"; Количество: {product.Value}");
            }
        }

        public void Sell(Product product)
        {
            if (products.ContainsKey(product))
            {
                if (products[product] == 0)
                {
                    Console.WriteLine("Нет в наличии!");
                }
                else
                {
                    products[product]--;
                    profit += product.Price; // Увеличиваем прибыль
                    Console.WriteLine($"Продан: {product.Name}. Прибыль: {profit} руб.");
                }
            }
            else
            {
                Console.WriteLine("Товар не найден!");
            }
        }

        public void Sell(string productName, int count)
        {
            Product toSell = FindByName(productName);
            if (toSell != null)
            {
                if (products[toSell] < count)
                {
                    MessageBox.Show("Недостаточно товара в наличии для продажи.");
                    return;
                }

                for (int i = 0; i < count; i++)
                {
                    Sell(toSell); // Продаем товар указанное количество раз
                }
            }
            else
            {
                MessageBox.Show("Товар не найден!");
            }
        }

        public Product FindByName(string name)
        {
            foreach (var product in products.Keys)
            {
                if (product.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) // Сравнение без учета регистра
                {
                    return product;
                }
            }
            return null;
        }

        public Dictionary<Product, int> GetProducts()
        {
            return products;
        }

        public decimal GetProfit()
        {
            return profit; // Возвращаем текущее значение прибыли
        }
    }
}

