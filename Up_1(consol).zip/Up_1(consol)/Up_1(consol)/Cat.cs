﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Up_1_consol_
{
    internal class Cat
    {
        private string name;
        public string Name // свойство, реализуем инкапсуляцию!
        {
            // получение значения - просто возврат name
            get
            {
                return name;
            }
            // установка значения - используем проверку
            set
            {
                bool OnlyLetters = true;
                // ключ. слово value - это то, что хотят свойству присвоить
                foreach (var ch in value)
                {
                    if (!char.IsLetter(ch))
                    {
                        OnlyLetters = false;
                    }
                }

                if (OnlyLetters)
                {
                    name = value;
                }
                else
                {
                    Console.WriteLine($"{value} - неправильное имя!!!");
                }
            }
        }
        private double weight; // скрытое поле для веса
        public double Weight // свойство для установки и получения веса
        {
            get
            {
                return weight; // просто возврат текущего веса
            }
            set
            {
                // Проверка, чтобы вес был положительным
                if (value < 0)
                {
                    Console.WriteLine($"{value} - неправильный вес!!! Вес не может быть отрицательным.");
                }
                else
                {
                    weight = value; // установка веса
                }
            }
        }

        public Cat(string CatName)
        {
            Name = CatName;
        }

        public void Meow()
        {
            Console.WriteLine($"{name}: МЯЯЯЯУ!!!!");
            Console.WriteLine($"вес кота {name}: {weight}");
        }
        public void SetCatName(string CatName)
        {

            bool OnlyLetters = true;

            foreach (var ch in CatName)
            {
                if (!char.IsLetter(ch))
                {
                    OnlyLetters = false;
                }
            }

            if (OnlyLetters)
                name = CatName;
            else
                Console.WriteLine($"{CatName} - неправильное имя!!!");
        }
    }

}
