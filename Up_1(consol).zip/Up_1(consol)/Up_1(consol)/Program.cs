﻿
using Up_1_consol_;

Cat murzik = new Cat("Мурзик");
Cat barsik = new Cat("Барсег");
murzik.Meow();
barsik.Meow();
barsik.Name = "Барсик";
barsik.Meow();
barsik.Name = "1234";
barsik.Meow();
barsik.Weight = 10.5;
barsik.Meow();